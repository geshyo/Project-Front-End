<hr> 
<div class="panel panel-gradient" >
 
 
				<img src="uploads/img/academic.png"  alt="" />
	      
           
</div>