<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="mystyle.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Resume</title>
</head>
<body ononline="onFunction()" onoffline="offFunction()" bgcolor="EDF2F8"> 

</head>
<body>
<h2>YOGESH</h2>
<ul>
  <li><a class="active" href="#home">Home</a></li>
  <li><a href="#projects">My Projects</a></li>
  <li><a href="#about">About me</a></li>
  <li><a href="#education">Education</a></li>
</ul>

<div class="dot"></div>
<div class="dot1"></div>
</body>
</html>